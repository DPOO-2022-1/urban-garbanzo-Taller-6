package uniandes.dpoo.taller1.modelo;

public class CategoriaNoExisteEXP extends Exception {

	private static final long serialVersionUID = 1L;

	public CategoriaNoExisteEXP(String EXPerror) {
		super(EXPerror);
	}
}