package uniandes.dpoo.taller1.modelo;


public class YaExisteNombreEXP extends Exception {

	private static final long serialVersionUID = 1L;

	public YaExisteNombreEXP(String EXPerror) {
		super(EXPerror);
	}
}